# Find the Bugs

### Installing

1. Download JavaOneFindTheBugs.zip
2. Extract JavaOneFindTheBugs.zip to `C:\FindTheBugs`. Extracted contents should include:

	```
	 C:\FindTheBugs\workspace
	```  
3. Open Eclipse Neon. You should be prompted for a workspace, enter C:\FindTheBugs\workspace. If the case you are not prompted, then use File/switch Workspace menu and point to the same directory  
4. From the workspace directory, create a shortcut to funbot.bat (or funbob.sh if on mac) and put it on the desktop

### Playing

1. Click on the `FunBob` Desktop shortcut to launch the FunBob application. The FunBob application contains three games:

	* Guess My Number
	* Tic Tac Toe
	* JavaNoid

2. Play the games
3. Find the bugs

### Debugging

1. If you don't already have it, create a shortcut to Eclipse Neon and put it on the desktop.  
2. Click on the `Eclipse` Desktop shortcut to launch the Eclipse environment. The Eclipse environment should already point at the funbob workspace. If not follow step 3 above  
3. Debug the code
4. Fix the bugs

