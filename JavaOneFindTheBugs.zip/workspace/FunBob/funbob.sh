java -XstartOnFirstThread -classpath ./bin:\
org.eclipse.ui_3.108.0.v20160518-1929.jar:\
org.eclipse.swt_3.105.0.v20160603-0902.jar:\
org.eclipse.swt.cocoa.macosx.x86_64_3.105.0.v20160603-0902.jar:\
org.eclipse.jface_3.12.0.v20160518-1929.jar:\
org.eclipse.core.commands_3.8.0.v20160316-1921.jar:\
org.eclipse.equinox.common_3.8.0.v20160509-1230.jar \
guessmynumber.GuessMyNumberMainWindow