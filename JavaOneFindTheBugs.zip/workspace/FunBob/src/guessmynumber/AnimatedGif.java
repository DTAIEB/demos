/**
 * 
 */
package guessmynumber;

import java.io.InputStream;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author dtaieb
 *
 */
public class AnimatedGif {
	
	private Shell shell;
	private GC shellGC;
	private Color shellBackground;
	private ImageLoader loader;
	private ImageData[] imageDataArray;
	private Thread animateThread;
	private Image image;
	private final boolean useGIFBackground = true;
	private Rectangle parentBounds;
	private boolean bStop = false;
	
	public AnimatedGif(Shell shellParent ){
		shell = new Shell( shellParent.getDisplay(), SWT.NO_TRIM | SWT.NO_BACKGROUND );
		shell.addMouseListener( new MouseListener() {		
			public void mouseUp(MouseEvent e) {
				bStop = true;
			}		
			public void mouseDown(MouseEvent e) {
			}
		
			public void mouseDoubleClick(MouseEvent e) {
			}		
		} );
		parentBounds = shellParent.getBounds();		
		shellGC = new GC(shell);
		shellBackground = shell.getBackground();
		loader = new ImageLoader();
	}
	
	private Display getDisplay() {
		return shell.getDisplay();
	}
	
	private Shell getShell(){
		return shell;
	}
	
	public void run(InputStream is ){
		try {
			imageDataArray = loader.load( is );
			
			getShell().open();
			getShell().setBounds( parentBounds.x, parentBounds.y,  loader.logicalScreenWidth, loader.logicalScreenHeight);

			if (imageDataArray.length > 1) {
				animateThread = new Thread("Animation") {
					public void run() {
						/* Create an off-screen image to draw on, and fill it with the shell background. */
						Image offScreenImage = new Image(getDisplay(), loader.logicalScreenWidth, loader.logicalScreenHeight);
						GC offScreenImageGC = new GC(offScreenImage);
						offScreenImageGC.setBackground(shellBackground);
						offScreenImageGC.fillRectangle(0, 0, loader.logicalScreenWidth, loader.logicalScreenHeight);

						try {
							/* Create the first image and draw it on the off-screen image. */
							int imageDataIndex = 0;  
							ImageData imageData = imageDataArray[imageDataIndex];
							if (image != null && !image.isDisposed()) image.dispose();
							image = new Image(getDisplay(), imageData);
							offScreenImageGC.drawImage(
									image,
									0,
									0,
									imageData.width,
									imageData.height,
									imageData.x,
									imageData.y,
									imageData.width,
									imageData.height);

							/* Now loop through the images, creating and drawing each one
							 * on the off-screen image before drawing it on the shell. */
							int repeatCount = loader.repeatCount;
							int iCount = 0;
							while (loader.repeatCount == 0 || repeatCount > 0) {
								if ( bStop ){
									closeShell();
									return;
								}
								
								if ( iCount % 5 == 0 ){
									//Move the window
									bStop = moveShell();
									iCount = 0;
								}
								switch (imageData.disposalMethod) {
								case SWT.DM_FILL_BACKGROUND:
									/* Fill with the background color before drawing. */
									Color bgColor = null;
									if (useGIFBackground && loader.backgroundPixel != -1) {
										//bgColor = new Color(getDisplay(), imageData.palette.getRGB(loader.backgroundPixel));
										bgColor = new Color(getDisplay(), new RGB( 255,255,255 ));
									}
									offScreenImageGC.setBackground(bgColor != null ? bgColor : shellBackground);
									offScreenImageGC.fillRectangle(imageData.x, imageData.y, imageData.width, imageData.height);
									if (bgColor != null) bgColor.dispose();
									break;
								case SWT.DM_FILL_PREVIOUS:
									/* Restore the previous image before drawing. */
									offScreenImageGC.drawImage(
											image,
											0,
											0,
											imageData.width,
											imageData.height,
											imageData.x,
											imageData.y,
											imageData.width,
											imageData.height);
									break;
								}

								imageDataIndex = (imageDataIndex + 1) % imageDataArray.length;
								imageData = imageDataArray[imageDataIndex];
								image.dispose();
								image = new Image(getDisplay(), imageData);
								offScreenImageGC.drawImage(
										image,
										0,
										0,
										imageData.width,
										imageData.height,
										imageData.x,
										imageData.y,
										imageData.width,
										imageData.height);

								/* Draw the off-screen image to the shell. */
								shellGC.drawImage(offScreenImage, 0, 0);

								/* Sleep for the specified delay time (adding commonly-used slow-down fudge factors). */
								try {
									int ms = imageData.delayTime * 10;
									if (ms < 20) ms += 30;
									if (ms < 30) ms += 10;
									Thread.sleep(ms);
								} catch (InterruptedException e) {
								}

								/* If we have just drawn the last image, decrement the repeat count and start again. */
								if (imageDataIndex == imageDataArray.length - 1) repeatCount--;
							}
						} catch (SWTException ex) {
							ex.printStackTrace();
							MessageDialog.openError(getShell(), "error", "There was an error animating the GIF");
						} finally {
							if (offScreenImage != null && !offScreenImage.isDisposed()) offScreenImage.dispose();
							if (offScreenImageGC != null && !offScreenImageGC.isDisposed()) offScreenImageGC.dispose();
							if (image != null && !image.isDisposed()) image.dispose();
						}
					}

				};
				animateThread.setDaemon(true);
				animateThread.start();
			}
		} catch (SWTException ex) {
			System.out.println("There was an error loading the GIF");
		}
	}

	protected void closeShell() {
		getShell().getDisplay().syncExec( new Runnable() {		
			public void run() {
				getShell().close();
			}		
		});		
	}

	protected boolean moveShell() {
		final boolean[] bool = new boolean[1];
		getShell().getDisplay().syncExec( new Runnable() {		
			public void run() {
				Point pt = getShell().getLocation();
				pt.x += 5;
				pt.y += 5;
				getShell().setLocation( pt );
				if ( pt.x > (parentBounds.x + parentBounds.width)  || pt.y > ( parentBounds.y + parentBounds.height )){
					bool[0] =  true;
				}else{
					bool[0] =  false;
				}
			}		
		});
		return bool[0];
	}

}
