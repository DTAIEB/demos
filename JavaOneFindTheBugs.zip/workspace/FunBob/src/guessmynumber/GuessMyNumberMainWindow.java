/**
 * 
 */
package guessmynumber;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Random;

import javax.swing.SwingUtilities;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Decorations;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;

import guessmynumber.javanoid.Javanoid;
import guessmynumber.tictactoe.game.GameInfos;
import guessmynumber.tictactoe.gui.GameComposite;

/**
 * @author dtaieb
 *
 */
public class GuessMyNumberMainWindow extends Window {
	
	private static final int MAX_NUMBER = 10;

	public static Shell mainShell = null;
	private MenuManager menuBarManager;
	
	private Font funbobFont = null;
	private ImageRegistry imageRegistry = null;

	private Font textFont;
	private int numberToGuess;

	private Text inputText;
	private Text responseText;
	private int iTurn;
	
	HashSet<String> who = new HashSet<String>();

	private static Label pointsLabel;
	private static int points = 0;

	/**
	 * @param parentShell
	 */
	public GuessMyNumberMainWindow(Shell parentShell) {
		super(parentShell);
		
		BufferedReader br = new BufferedReader( new InputStreamReader( getClass().getResourceAsStream( "who.txt")) );
		try {
			String line;
			while ( (line = br.readLine()) != null ) {
				who.add( line );
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	 */
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		
		newShell.setText( "Welcome " + getName() );
		
        if (menuBarManager != null) {
            menuBarManager.updateAll(true);
            newShell.setMenuBar(menuBarManager.createMenuBar((Decorations) newShell));
        }
        
        imageRegistry = new ImageRegistry( newShell.getDisplay() );
        
		mainShell = newShell;
	}

	private String getName() {
		String[] names = who.toArray( new String[0]);
		if ( names == null || names.length == 0 ){
			return "";
		}
		return names[ Math.abs( new Random().nextInt() ) % names.length ];
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.window.Window#createContents(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createContents(Composite parent) {		
		Composite contents = (Composite)super.createContents(parent);
		contents.setLayout( new GridLayout( 2, false));
		contents.setLayoutData( new GridData( GridData.FILL_BOTH ));
		
		Label funbob = new Label( contents, SWT.NONE );
		funbob.setAlignment( SWT.CENTER );
		funbob.setFont( getFunbobFont() );
		funbob.setText( "FunBob" );
		GridData gd = new GridData( GridData.FILL_HORIZONTAL | GridData.CENTER);
		gd.horizontalSpan = 2;
		funbob.setLayoutData( gd );
		
		Label logo = new Label( contents, SWT.NONE );
		logo.setImage( getImage( "logo.GIF" ) );
		logo.addMouseListener( new MouseListener() {
		
			public void mouseUp(MouseEvent e) {
				processClick(e);
			}
		
			public void mouseDown(MouseEvent e) {
			}
		
			public void mouseDoubleClick(MouseEvent e) {
				processClick( e );
			}

			private void processClick(MouseEvent e) {
				if ( e.x > 50 && e.x < 90 && e.y > 80 && e.y < 100 ){
					MessageDialog.openInformation( getShell(), "funbob", "you click on my hat");
				}else if ( e.x > 87 && e.x < 150 && e.y > 140 && e.y < 207 ){
					MessageDialog.openInformation( getShell(), "funbob", "you click on my moustache");
				}				
			}
		
		} );
		
		Composite mainContents = new Composite( contents, SWT.NONE );
		mainContents.setLayout( new GridLayout(1, false ) );
		mainContents.setLayoutData( new GridData( GridData.FILL_BOTH ));
		createMainContents( mainContents );
		
		Composite bottomContents = new Composite( contents, SWT.NONE );
		gd = new GridData( GridData.HORIZONTAL_ALIGN_CENTER );
		gd.horizontalSpan = 2;
		bottomContents.setLayoutData( gd );
		bottomContents.setLayout( new GridLayout(3, false ) );
		Label exitLabel = new Label( bottomContents, SWT.NONE );
		exitLabel.setImage( getImage( "exit.GIF" ));
		exitLabel.addMouseListener( new MouseListener() {		
			public void mouseUp(MouseEvent e) { close(); }		
			public void mouseDown(MouseEvent e) {}		
			public void mouseDoubleClick(MouseEvent e) {}		
		} );
		
		Label startOverLabel = new Label( bottomContents, SWT.NONE );
		startOverLabel.setImage( getImage( "startOver.GIF"));
		startOverLabel.addMouseListener( new MouseListener() {		
			public void mouseUp(MouseEvent e) { onStartOver(); }		
			public void mouseDown(MouseEvent e) {}		
			public void mouseDoubleClick(MouseEvent e) {}		
		} );
		
		pointsLabel = new Label( bottomContents, SWT.NONE );
		pointsLabel.setText("Points: 0");
		gd = new GridData( GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_END );
		pointsLabel.setLayoutData( gd );
		
		onStartOver();

		return contents;
	}
	
	/**
	 * 
	 */
	protected void onStartOver() {
		numberToGuess = new Random().nextInt( MAX_NUMBER );
		inputText.setText("");
		responseText.setText("");	
		iTurn = 0;
	}

	/**
	 * @param parent
	 */
	private void createMainContents(Composite parent) {
		CTabFolder tabFolder = new CTabFolder( parent, SWT.BORDER );
		
		CTabItem tabItem = new CTabItem( tabFolder, SWT.NONE );
		tabItem.setText( "Guess a Number");
		Composite gameComposite = new Composite( tabFolder, SWT.BORDER );
		gameComposite.setLayout( new GridLayout(2, false ) );
		tabItem.setControl(  gameComposite );
		createGuessNumberControl( gameComposite );
		
		tabItem = new CTabItem( tabFolder, SWT.NONE );
		tabItem.setText( "TIC TAC TOE ");
		gameComposite = new Composite( tabFolder, SWT.BORDER );
		gameComposite.setLayout( new GridLayout() );
		tabItem.setControl(  gameComposite );
		createTicTacToeControl( gameComposite );
		
		final CTabItem javanoidItem = new CTabItem( tabFolder, SWT.NONE );
		javanoidItem.setText( "JAVANOID" );
		gameComposite = new Composite( tabFolder, SWT.BORDER );
		gameComposite.setLayout( new GridLayout() );
		javanoidItem.setControl(  gameComposite );
		createJavanoidControl( gameComposite );
		
		//Add Code for Online game here
		
	}

	/**
	 * @param gameComposite
	 */
	private void createJavanoidControl(Composite gameComposite) {
		final Composite swtAwtComponent = new Composite( gameComposite, SWT.EMBEDDED | SWT.BORDER);
		swtAwtComponent.setLayoutData( new GridData( GridData.FILL_BOTH ) );
		java.awt.Frame frame = SWT_AWT.new_Frame( swtAwtComponent );
		final Javanoid javanoidPanel = new Javanoid(swtAwtComponent);
		frame.add( javanoidPanel);
		SwingUtilities.invokeLater( new Runnable() {			
			public void run() {
				javanoidPanel.init();
			}
		});
		
		swtAwtComponent.addDisposeListener( new DisposeListener( ) {			
			public void widgetDisposed(DisposeEvent e) {
				javanoidPanel.stopGame();
			}
		});
		
		gameComposite.getParent().layout( true );
	}

	private void createTicTacToeControl(Composite parent) {
		ToolBar tb = new ToolBar( parent, SWT.NONE );
		ToolItem ti = new ToolItem( tb, SWT.NONE );
		ti.setText("New Game");

		final GameComposite tictactoeGame = new GameComposite( parent, 100 );
		tictactoeGame.setNewGame( new GameInfos( 0, 1 ));
		ti.addSelectionListener( new SelectionListener() {		
			public void widgetSelected(SelectionEvent arg0) {
				tictactoeGame.setNewGame( new GameInfos( 0, 1 ) );
			}
		
			public void widgetDefaultSelected(SelectionEvent arg0) {
			}
		} );
	}

	private void createGuessNumberControl(Composite parent) {
		Text text = new Text( parent, SWT.BORDER | SWT.MULTI );
		text.setFont( getTextFont() );
		text.setText( "How to Play: \r\n\r\n" +
				"The FunBob Magician will pick a secret number and put it in his hat.\r\n" +
				"You guess what number it is.\r\n\r\n" +
				"If your guess is too high or too low, FunBob will give you a hint. \r\n" +
				"See how many turns it takes you to win!");
		
		GridData gd = new GridData( GridData.FILL_HORIZONTAL );
		gd.horizontalSpan = 2;
		text.setLayoutData( gd );
		
		inputText = new Text( parent, SWT.BORDER );
		gd = new GridData();
		gd.heightHint = 25;
		gd.widthHint = 150;
		inputText.setLayoutData(gd );
		Label guessLabel = new Label( parent, SWT.NONE );
		guessLabel.setImage( getImage( "guess.GIF") );
		guessLabel.addMouseListener( new MouseListener() {		
			public void mouseUp(MouseEvent e) {	
				onGuessButtonClick();
			}
		
			public void mouseDown(MouseEvent e) {
			}
		
			public void mouseDoubleClick(MouseEvent e) {
			}		
		});
		
		responseText = new Text( parent, SWT.BORDER );
		gd = new GridData();
		gd.horizontalSpan = 2;
		gd.heightHint = 70;
		gd.widthHint = 300;
		responseText.setLayoutData( gd );		
	}

	/**
	 * 
	 */
	protected void onGuessButtonClick() {
		try {
			int i = Integer.valueOf( inputText.getText() ).intValue();
			if ( i == numberToGuess ){
				displayMessage("You guessed right!!!");
				displayAnimatedGif( getShell() );
			}else if ( i > MAX_NUMBER ){
				displayMessage( "Number cannot be greater than " + MAX_NUMBER );
			}else if ( i < numberToGuess ){
				displayMessage( "Nice try, but it is too low.");
			}else if ( i > numberToGuess ){
				displayMessage( "Turn1: Nice try, but it is too high.");
			}
		} catch (NumberFormatException e) {
			//displayMessage( "Not a number");
			MessageDialog.openError(getShell(), "FunBob", "Error 0x324A !@#$");
			close();
		}
	}

	/**
	 * 
	 */
	public static void displayAnimatedGif( Shell shell ) {
		if ( shell == null ){
			shell = mainShell;
		}
		new AnimatedGif( shell ).run( GuessMyNumberMainWindow.class.getResourceAsStream( "rabbit.gif" ));
	}

	private void displayMessage(String message) {
		responseText.setText( "Turn " + (++iTurn * 2) + ": " + message );		
	}

	/**
	 * @return
	 */
	private Image getImage(final String imageRes ) {
		Image image = imageRegistry.get( imageRes );
		if ( image == null ){
			image = new ImageDescriptor() {		
				public ImageData getImageData() {
					InputStream is = null;
					try{
						is = getClass().getResourceAsStream( imageRes);
						return new ImageData( is );
					}finally{
						if ( is != null ){
							try {
								is.close();
							} catch (IOException e) {}
						}
					}
				}
			}.createImage();
			imageRegistry.put( imageRes, image);
		}
		return image;
	}
	
	private Font getTextFont() {
		if ( textFont == null ){
			textFont = new Font(getShell().getDisplay(), "Verdana", 12, SWT.NORMAL );
		}
		return textFont;
	}

	/**
	 * @return
	 */
	private Font getFunbobFont() {
		if ( funbobFont == null ){
			funbobFont = new Font(getShell().getDisplay(), "Times New Roman", 25, SWT.ITALIC );
		}
		return funbobFont;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell( display );
		
		GuessMyNumberMainWindow window = new GuessMyNumberMainWindow( shell );
		window.setBlockOnOpen( true );
		
		window.create();
		window.getShell().pack();
		window.open();
	    display.dispose();
	}
	
	public boolean close() {
		boolean bRet = super.close();
		
		if ( funbobFont != null ){
			funbobFont.dispose();
		}
		
		imageRegistry.dispose();
		return bRet;
	}

	public static void addPoint() {
		pointsLabel.setText("Points: " + ++points);
	}
	
}
