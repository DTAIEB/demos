/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe;
import guessmynumber.tictactoe.game.Game;
import guessmynumber.tictactoe.game.GameInfos;
import guessmynumber.tictactoe.game.PlayException;

/**
 * Game console version
 * @author R-One
 */
public class ConsoleMain {

	public static void main(String[] args) {
		Game game = new Game(new GameInfos(GameInfos.Human,GameInfos.Computer));
		byte[][] state;
		int l, c;
		java.io.BufferedReader is = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
		while (game.gameOver() == -1) {
			try {
				if (game.playerTurn() == 1) {
					String line = is.readLine();
					l = Integer.parseInt(line);
					line = is.readLine();
					c = Integer.parseInt(line);
					game.play((byte)l,(byte)c);
				}
				else
					game.play(0,0);
				state = game.getState();
				for (byte i=0; i<3; i++) {
					for (byte j=0; j<3; j++)
						System.out.print(state[i][j]);
					System.out.println();
				}
				System.out.println();
			}
			catch (PlayException pe) {
				System.out.println(pe.getMessage());
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}//main

}//ConsoleMain
