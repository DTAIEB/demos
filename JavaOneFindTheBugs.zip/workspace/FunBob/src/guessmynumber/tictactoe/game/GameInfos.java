/*
 * Created on 12 oct. 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package guessmynumber.tictactoe.game;

/**
 * Game informations to create a new one
 * @author R-One
 */
public class GameInfos {

	// Player types
	public final static int Human    = 0,
							Computer = 1;

	// Player type (human or computer)
	protected int player1, player2;

	/**
	 * Create a game info structure
	 * @param player1
	 * @param player2
	 */
	public GameInfos(int player1, int player2) {
		this.player1 = player1;
		this.player2 = player2;
	}//Constructor

	/**
	 * Get player 1 type
	 * @return player type
	 */
	public int getPlayer1() { return this.player1; }

	/**
	 * Get player 2 type
	 * @return player type
	 */
	public int getPlayer2() { return this.player2; }

}//GameInfos
