/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * Play exception
 * @author R-One
 */
public class PlayException extends Exception {

	public PlayException(String message) {
		super(message);
	}//Constructor

}//PlayException
