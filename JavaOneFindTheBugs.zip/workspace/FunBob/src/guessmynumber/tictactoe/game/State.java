/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * Define the state of the game : which squares are used by who
 * @author R-One
 */
class State {

	// Define the state of a square
	protected final static byte Empty = 0, Player1 = 1, Player2 = 2;

	// Game state matrix
	protected byte[][] state;

	/**
	 * Instanciate a game state.
	 */
	public State() {
		this.state = new byte[3][3];
		for (int i=0; i<3; i++)
			for (int j=0; j<3; j++)
				this.state[i][j] = Empty;
	}//Constructor
	
	/**
	 * Instanciate a game state.
	 * @param state the state to copy
	 */
	public State(State state) {
		this.state = new byte[3][3];
		for (int i=0; i<3; i++)
			for (int j=0; j<3; j++)
				this.state[i][j] = state.state[i][j];
	}//Constructor
	
	/**
	 * Make a move
	 * @param player 1 = player1, 2 = player2
	 * @param line played line
	 * @param column played column
	 * @throws PlayException if the move is not correct
	 */
	public void play(byte player, byte line, byte column) throws PlayException {
		if ((player != 1) && (player != 2))
			throw new PlayException("Bad player number, must be 1 or 2");
		if ((line < 1) || (line > 3))
			throw new PlayException("Bad line number, must be between 1 and 3");
		if ((column < 1) || (column > 3))
			throw new PlayException("Bad column number, must be between 1 and 3");
		if (this.state[line-1][column-1] != Empty)
			throw new PlayException("Move "+line+"x"+column+" has already been played");
		this.state[line-1][column-1] = player;
	}//play

	/**
	 * Return the state of the move at the given line and column.
	 * @param line
	 * @param column
	 * @return the state of the square
	 * @throws PlayException if the move is not correct
	 */
	public byte getMove(byte line, byte column) throws PlayException {
		if ((line < 1) || (line > 3))
			throw new PlayException("Bad line number, must be between 1 and 3");
		if ((column < 1) || (column > 3))
			throw new PlayException("Bad column number, must be between 1 and 3");
		return this.state[line-1][column-1];
	}//getMove
	
	/**
	 * Return true if the square is free
	 * @param line
	 * @param column
	 * @return trye if free, false else
	 * @throws PlayException
	 */
	public boolean isFree(byte line, byte column) throws PlayException {
		if ((line < 1) || (line > 3))
			throw new PlayException("Bad line number, must be between 1 and 3");
		if ((column < 1) || (column > 3))
			throw new PlayException("Bad column number, must be between 1 and 3");
		return this.state[line-1][column-1] == Empty;
	}//isFree

	/**
	 * Return the number of free squares
	 * @return number of free squares
	 */
	public byte nbFree() {
		byte nbFree = 0;
		for (byte i=0; i<3; i++) {
			for (byte j=0; j<3; j++) {
				if (this.state[i][j] == Empty)
					nbFree++;
			}
		}
		return nbFree;
	}//nbFree

}//State
