/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * Define the structure of a decision class algorithm
 * @author R-One
 */
abstract class Decision {

	/**
	 * Analyse possible moves
	 * @param state Current game state
	 * @param player doing the move
	 * @param playerTurn True if the move is played by the player to simulate
	 * @param depth Depth in the decision tree
	 * @return analysed possible moves
	 */
	public abstract Move[] analyseMoves(State state, byte player, boolean playerTurn, byte depth);

	/**
	 * Decide the move to do.
	 * @param state current state
	 * @param player Current player
	 * @return the move to do
	 * @throws PlayException if all moves have been done
	 */
	public Move decideMove(State state, byte player) throws PlayException {
		Move[] moves = this.analyseMoves(state,player,true,(byte)0);
		if (moves.length == 0)
			throw new PlayException("No more moves to process");
		short index = 0;
		int max = 0;
		max = moves[0].getValue();
		for (short i=1; i<moves.length; i++) {
			if (moves[i].getValue() > max) {
				max = moves[i].getValue();
				index = i;
			}
		}
		return moves[index];
	}//decideMove

	/**
	 * Analyse the state to tell if anyone wins.
	 * @param state state to analyse
	 * @param player current player
	 * @return True if the current player wins
	 */	
	protected boolean analyseState(State state, byte player) {
		byte v1 = 1, v2 = 2, v3 = 3;
		try {
			if ((state.getMove(v1,v1) == state.getMove(v1,v2)) &&
				(state.getMove(v1,v1) == state.getMove(v1,v3)) &&
				(state.getMove(v1,v1) == player))
				return true;
			if ((state.getMove(v2,v1) == state.getMove(v2,v2)) &&
				(state.getMove(v2,v1) == state.getMove(v2,v3)) &&
				(state.getMove(v2,v1) == player))
				return true;
			if ((state.getMove(v3,v1) == state.getMove(v3,v2)) &&
				(state.getMove(v3,v1) == state.getMove(v3,v3)) &&
				(state.getMove(v3,v1) == player))
				return true;
			if ((state.getMove(v1,v1) == state.getMove(v2,v1)) &&
				(state.getMove(v1,v1) == state.getMove(v3,v1)) &&
				(state.getMove(v1,v1) == player))
				return true;
			if ((state.getMove(v1,v2) == state.getMove(v2,v2)) &&
				(state.getMove(v1,v2) == state.getMove(v3,v2)) &&
				(state.getMove(v1,v2) == player))
				return true;
			if ((state.getMove(v1,v3) == state.getMove(v2,v3)) &&
				(state.getMove(v1,v3) == state.getMove(v3,v3)) &&
				(state.getMove(v1,v3) == player))
				return true;
			if ((state.getMove(v1,v1) == state.getMove(v2,v2)) &&
				(state.getMove(v1,v1) == state.getMove(v3,v3)) &&
				(state.getMove(v1,v1) == player))
				return true;
			if ((state.getMove(v3,v1) == state.getMove(v2,v2)) &&
				(state.getMove(v3,v1) == state.getMove(v1,v3)) &&
				(state.getMove(v3,v1) == player))
				return true;
		}
		catch (PlayException pe) {}
		return false;
	}//analyseState

}//Decision
