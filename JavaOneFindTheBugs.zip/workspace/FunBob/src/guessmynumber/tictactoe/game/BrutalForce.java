/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * This class makes decisions with the brutal force algorithm
 * @author R-One
 */
class BrutalForce extends Decision {

	// Final game state value 
	protected static final short Win = 10, Loose = -10, Equal = 0;

	/**
	 * Analyse all possible moves with the brutal force algorithm
	 * @param state Current game state
	 * @param player doing the move
	 * @param playerTurn True if the move is played by the player to simulate
	 * @param depth Depth in the decision tree
	 * @return analysed possible moves
	 */
	public Move[] analyseMoves(State state, byte player, boolean playerTurn, byte depth) {
		Move[] moves = new Move[state.nbFree()];
		byte otherPlayer;
		int coef = 10 - depth;
		if (player == 1) otherPlayer = 2;
		else otherPlayer = 1;
		byte index = 0;
		byte event;
		State tempState;
		//System.out.println("-- "+depth+" --");
		try {
			for (byte line=1; line<=3; line++) {
				for (byte column=1; column<=3; column++) {
					if (state.isFree(line,column)) {
						tempState = new State(state);
						tempState.play(player,line,column);
						if (this.analyseState(tempState,player)) {
							if (playerTurn)
								moves[index] = new Move(line,column,Win*coef);
							else
								moves[index] = new Move(line,column,Loose*coef);
							//System.out.println("W : d = "+depth+" l = "+line+" c = "+column+" v = "+moves[index].getValue());
						}
						else {
							if (tempState.nbFree() == 0) {
								moves[index] = new Move(line,column,Equal*coef);
								//System.out.println("E : d = "+depth+" l = "+line+" c = "+column+" v = "+moves[index].getValue());
							}
							else {
								int value;
								Move[] nextMoves = this.analyseMoves(tempState,otherPlayer,!playerTurn,(byte)(depth+1));
								value = nextMoves[0].getValue();
								if (playerTurn) {
									for (int i=1; i<nextMoves.length; i++) {
										if (value < nextMoves[i].getValue())
											value = nextMoves[i].getValue();
									}
								}
								else {
									for (int i=1; i<nextMoves.length; i++) {
										if (value > nextMoves[i].getValue())
											value = nextMoves[i].getValue();
									}
								}
								moves[index] = new Move(line,column,value);
								//if (depth < 1)
								//System.out.println("R : d = "+depth+" l = "+line+" c = "+column+" v = "+moves[index].getValue());
							}
						}
						index++;
					}
				}
			}
		}
		catch (PlayException pe) {
			System.out.println(pe.getMessage());
			return null;
		}
		return moves;
	}//analyseMoves

}//BrutalForce
