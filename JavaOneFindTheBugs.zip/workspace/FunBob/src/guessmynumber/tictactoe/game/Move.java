/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * Define a move on the game (line, column, value)
 * @author R-One
 */
class Move {

	// Moves properties
	protected byte line, column;
	
	// Move value
	protected int value;

	/**
	 * Create a move : a line and a column
	 */
	public Move(byte line, byte column, int value) {
		this.line = line;
		this.column = column;
		this.value = value;
	}//Constructor

	/**
	 * Return the move line
	 * @return the line
	 */
	public byte getLine() { return this.line; }

	/**
	 * Return the move column
	 * @return the column
	 */
	public byte getColumn() { return this.column; }

	/**
	 * Return the move value
	 * @return the value
	 */
	public int getValue() { return this.value; }

}//Move
