/*
 * Created on 1 oct. 2004
 *
 */
package guessmynumber.tictactoe.game;

/**
 * JMorback game interface
 * @author R-One
 */
public class Game {

	// Player turn to play
	protected boolean player1Turn;

	// Game informations
	protected GameInfos gameInfos;

	// Game state
	protected State state;
	
	// Decision algorithm
	protected Decision decision;
	
	//	Last played line and column
	protected int lastLine, lastColumn;

	/**
	 * Create a new game
	 * @param gameInfos Game informations (players type)
	 */
	public Game(GameInfos gameInfos) {
		this.gameInfos = gameInfos;
		this.reset();
		this.decision = new BrutalForce();
	}//Constructor
	
	/**
	 * Reset the game
	 */
	public void reset() {
		this.state = new State();
		this.player1Turn = true;
	}//reset
	
	/**
	 * Play next move
	 * @param line
	 * @param column
	 * @throws PlayException
	 */
	public void play(int line, int column) throws PlayException {
		if (this.gameOver() != -1)
			throw new PlayException("Game is over");
		try {
			if (player1Turn) {
				if (this.gameInfos.getPlayer1() == GameInfos.Human) {
					this.state.play((byte)1,(byte)line,(byte)column);
					this.lastLine = line;
					this.lastColumn = column;
				}
				else {
					Move move = this.decision.decideMove(this.state,(byte)1);
					this.lastLine = move.getLine();
					this.lastColumn = move.getColumn();
					this.state.play((byte)1,move.getLine(),move.getColumn());
				}
			}
			else {
				if (this.gameInfos.getPlayer2() == GameInfos.Human) {
					this.state.play((byte)2,(byte)line,(byte)column);
					this.lastLine = line;
					this.lastColumn = column;
				}
				else {
					Move move = this.decision.decideMove(this.state,(byte)2);
					this.lastLine = move.getLine();
					this.lastColumn = move.getColumn();
					this.state.play((byte)2,move.getLine(),move.getColumn());
				}
			}
			this.player1Turn = !this.player1Turn;
		}
		catch (PlayException pe) {
			throw pe;
		}
	}//play
	
	/**
	 * Tell if the game is over
	 * @return -1 if not, 0 if noone, 1 if player 1 won and 2 if player 2 won
	 */
	public int gameOver() {
		if (this.decision.analyseState(this.state,(byte)1)) return 1;
		if (this.decision.analyseState(this.state,(byte)2)) return 2;
		if (this.state.nbFree() == 0) return 0;
		return -1;
	}//gameOver

	/**
	 * Return the player turn
	 * @return player number
	 */
	public short playerTurn() {
		if (this.player1Turn) return 1;
		else return 2;
	}//playerTurn

	/**
	 * Return true if it's a human move
	 * @return true for human move
	 */
	public boolean humanTurn() {
		if (this.player1Turn && (this.gameInfos.getPlayer1() == GameInfos.Human))
			return true;
		if (!this.player1Turn && (this.gameInfos.getPlayer2() == GameInfos.Human))
			return true;
		return false;
	}//humanTurn

	/**
	 * Return game state
	 * @return game state matrix square
	 */
	public byte[][] getState() {
		byte[][] result = new byte[3][3];
		try {
			for (byte i=0; i<3; i++) {
				for (byte j=0; j<3; j++)
					result[i][j] = this.state.getMove((byte)(i+1),(byte)(j+1));
			}
		}
		catch (PlayException pe) {}
		return result;
	}//getState

	/**
	 * Return the last played line
	 * @return the last played line
	 */
	public int getLastLine() { return this.lastLine; }
	
	/**
	 * Return the last played column
	 * @return the last played column
	 */
	public int getLastColumn() { return this.lastColumn; }

}//Game
