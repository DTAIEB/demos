/*
 * Created on 5 oct. 2004
 *
 */
package guessmynumber.tictactoe;

import guessmynumber.tictactoe.gui.SWTMainFrame;

/**
 * Game SWT version
 * @author R-One
 */
public class SWTMain {

	public static void main(String[] args) {
		SWTMainFrame frame = new SWTMainFrame();
		frame.run();
	}//main

}//SWTMain
