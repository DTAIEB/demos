/*
 * Created on 5 oct. 2004
 *
 */
package guessmynumber.tictactoe.gui;

import guessmynumber.tictactoe.game.GameInfos;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

/**
 * Create a SWT interface for the JMorback game
 * @author R-One
 */
public class SWTMainFrame {

	// Display
	protected Display display;
	
	// Shell (widget manager)
	protected Shell shell;
	
	// Game composite
	protected GameComposite gameComposite;

	/**
	 * Create the SWT game frame
	 */
	public SWTMainFrame() {
		this.display = new Display();
		this.shell = new Shell(this.display);
		this.shell.setMenuBar(this.createMenuBar());
		this.shell.setSize(300,300);
		this.shell.setText("JMorback");
		this.gameComposite = new GameComposite(this.shell,100);
		this.shell.pack();
	}//Constructor
	
	/**
	 * Create the menu bar of the window
	 * @return the menu bar
	 */
	protected Menu createMenuBar() {
		Menu menuBar = new Menu(this.shell,SWT.BAR);
		MenuItem menuItemTitle, item;
		Menu menuTitle;
		// Game menu
		menuItemTitle = new MenuItem(menuBar,SWT.CASCADE);
		menuItemTitle.setText("Game");
		menuTitle = new Menu(menuItemTitle);
		menuItemTitle.setMenu(menuTitle);
		item = new MenuItem(menuTitle,SWT.NONE);
		item.setText("New");
		item.addSelectionListener(
			new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					GameInfos gameInfos = new NewGameDialog(shell).open();
					if (gameInfos != null)
						gameComposite.setNewGame(gameInfos);
				}
			}
		);
		item = new MenuItem(menuTitle,SWT.NONE);
		item.setText("Reset");
		item.addSelectionListener(
			new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					gameComposite.resetGame();
				}
			}
		);
		item = new MenuItem(menuTitle,SWT.SEPARATOR);
		item = new MenuItem(menuTitle,SWT.NONE);
		item.addSelectionListener(
			new SelectionAdapter() {
				public void widgetSelected(SelectionEvent e) {
					shell.dispose();
				}
			}
		);
		item.setText("Quit");
		// Return created menu
		return menuBar;
	}//createMenuBar
	
	/**
	 * Launch game gui
	 */
	public void run() {
		this.shell.open();
		while(!this.shell.isDisposed())
			if (!this.display.readAndDispatch())
				this.display.sleep();
		this.display.dispose();
	}//run

	/**
	 * 
	 * @author R-One
	 *
	 * Create a new game dialog box
	 */
	protected class NewGameDialog extends Dialog {
		
		// Dialog shell
		protected Shell shell;
		
		// Game informations
		protected GameInfos gameInfos;
		
		// Combo boxes
		protected Combo player1Combo, player2Combo;
		
		/**
		 * Create a new game dialog box
		 * @param parent
		 */
		public NewGameDialog(Shell parent) {
			super(parent,0);
			this.setText("New Game");
		}//Constructor
		
		/**
		 * Open the new game dialog box and return
		 * the new game informations
		 * @return new game informations
		 */
		public GameInfos open() {
			Shell parent = getParent();
			this.shell = new Shell(parent,SWT.DIALOG_TRIM|SWT.APPLICATION_MODAL);
			this.shell.setText(getText());
			Label label;
			Button button;
			label = new Label(this.shell,SWT.NONE);
			label.setText("Player 1 :");
			label.setSize(50,20);
			label.setLocation(5,7);
			player1Combo = new Combo(this.shell,SWT.DROP_DOWN|SWT.READ_ONLY);
			player1Combo.setSize(70,20);
			player1Combo.setLocation(60,5);
			player1Combo.setItems(new String[] {"Human","Computer"});
			player1Combo.select(0);
			label = new Label(this.shell,SWT.NONE);
			label.setText("Player 2 :");
			label.setSize(50,20);
			label.setLocation(5,32);
			player2Combo = new Combo(this.shell,SWT.DROP_DOWN|SWT.READ_ONLY);
			player2Combo.setSize(70,20);
			player2Combo.setLocation(60,30);
			player2Combo.setItems(new String[] {"Human","Computer"});
			player2Combo.select(1);
			button = new Button(shell,SWT.PUSH);
			button.setText("Ok");
			button.setSize(60,20);
			button.setLocation(5,55);
			button.addSelectionListener(
				new SelectionAdapter() {
					public void widgetSelected(SelectionEvent e) {
						close(getGameInfos());
					}
				}
			);
			button = new Button(shell,SWT.PUSH);
			button.setText("Cancel");
			button.setSize(60,20);
			button.setLocation(70,55);
			button.addSelectionListener(
				new SelectionAdapter() {
					public void widgetSelected(SelectionEvent e) {
						close(null);
					}
				}
			);
			// Display
			this.shell.pack();
			this.shell.open();
			Display display = parent.getDisplay();
			while (!this.shell.isDisposed()) {
				if (!display.readAndDispatch()) display.sleep();
			}
			return this.gameInfos;
		}//open
		
		/**
		 * Close the dialog and set the game informations
		 * @param gameInfos
		 */
		protected void close(GameInfos gameInfos) {
			this.gameInfos = gameInfos;
			this.shell.dispose();
		}//close
		
		/**
		 * Create the informations structure
		 * @return game informations
		 */
		protected GameInfos getGameInfos() {
			return new GameInfos(
				this.player1Combo.indexOf(this.player1Combo.getText()),
				this.player2Combo.indexOf(this.player2Combo.getText())
			);
		}//getGameInfos
		
	}//NewGameDialog

}//SWTMainFrame
