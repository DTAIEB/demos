/*
 * Created on 5 oct. 2004
 *
 */
package guessmynumber.tictactoe.gui;

import guessmynumber.GuessMyNumberMainWindow;
import guessmynumber.tictactoe.game.Game;
import guessmynumber.tictactoe.game.GameInfos;
import guessmynumber.tictactoe.game.PlayException;

import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

/**
 * Game composite (panel)
 * @author R-One
 */
public class GameComposite extends Composite {

	// Game image matrix
	protected Label[][] labels;
	
	// Pixels palette
	protected PaletteData paletteData;
	
	// Three images for the square states
	protected Image emptyImage, crossImage ,circleImage;
	
	// Popup message box
	protected MessageBox messageBox;
	
	// Game manager
	protected Game game;

	/**
	 * Create the game composite
	 * @param shell Parent shell
	 * @param game square side size
	 */
	public GameComposite(Composite parent, int squareSideSize) {
		super(parent,SWT.NONE);
		this.messageBox = new MessageBox( parent.getShell() );
		this.messageBox.setText("Game Message");
		this.paletteData = this.createPaletteData();
		this.emptyImage = new Image( parent.getDisplay(),this.createEmptyImageData(squareSideSize));
		this.crossImage = new Image( parent.getDisplay(),this.createCrossImageData(squareSideSize));
		this.circleImage = new Image( parent.getDisplay(),this.createCircleImageData(squareSideSize));
		this.initComponents();
	}//Constructor

	/**
	 * Initialize the graphic components
	 */
	protected void initComponents() {
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 3;
		this.setLayout(gridLayout);
		this.labels = new Label[3][3];
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				this.labels[i][j] = new Label(this,SWT.BORDER);
				this.labels[i][j].setImage(this.emptyImage);
				this.labels[i][j].addMouseListener(new SquareMouseListener(i+1,j+1));
			}
		}
		this.pack();
	}//initComponents

	/**
	 * Set the new game
	 * @param gameInfos new game information
	 */
	public void setNewGame(GameInfos gameInfos) {
		this.game = new Game(gameInfos);
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++)
				this.labels[i][j].setImage(this.emptyImage);
		}
		this.pack();
	}//setNewGame

	/**
	 * Create the pixel palette
	 * @return the palette
	 */
	protected PaletteData createPaletteData() {
		PaletteData paletteData = new PaletteData(0x00FF0000,0x0000FF00,0x000000FF);
		return paletteData;
	}//createPaletteData

	/**
	 * Create the empty square state image
	 * @param squareSideSize side size of the image
	 * @return the image data
	 */
	protected ImageData createEmptyImageData(int squareSideSize) {
		ImageData data = new ImageData(squareSideSize,squareSideSize,16,this.paletteData);
		return data;
	}//createEmptyImage

	/**
	 * Create the player 1 square state image
	 * @param squareSideSize side size of the image
	 * @return the image data
	 */
	protected ImageData createCrossImageData(int squareSideSize) {
		ImageData data = new ImageData(squareSideSize,squareSideSize,16,this.paletteData);
		for (int i=0; i<data.width-1; i++) {
			data.setPixel(i+1,i,0x000000FF);
			data.setPixel(i,i+1,0x000000FF);
			data.setPixel(i+1,data.width-i-1,0x0000FF00);
			data.setPixel(i,data.width-i-2,0x0000FF00);
		}
		return data;
	}//createCrossImageData

	/**
	 * Create the player 2 square state image
	 * @param squareSideSize side size of the image
	 * @return the image data
	 */
	protected ImageData createCircleImageData(int squareSideSize) {
		ImageData data = new ImageData(squareSideSize,squareSideSize,16,this.paletteData);
		int center = data.width/2;
		int ray = data.width/3;
		for (int i=center-ray; i<=center+ray; i++) {
			data.setPixel(i,center+(int)Math.sqrt(ray*ray-(i-center)*(i-center)),0x000000FF);
			data.setPixel(i,center+(int)Math.sqrt((ray-2)*(ray-2)-(i-center)*(i-center)),0x000000FF);
			data.setPixel(i,center-(int)Math.sqrt(ray*ray-(i-center)*(i-center)),0x0000FF00);
			data.setPixel(i,center-(int)Math.sqrt((ray-2)*(ray-2)-(i-center)*(i-center)),0x0000FF00);
		}
		return data;
	}//createCircleImageData

	/**
	 * Called when a mouse down event occurs on a square image
	 * @param line Selected line
	 * @param column Semected column
	 */
	protected void squareSelected(int line, int column) {
		try {
			int turn = game.playerTurn();
			boolean humanTurn = game.humanTurn();
			if ( humanTurn ){
				game.play((byte)line,(byte)column);
			}else{
				game.play(0,0);
			}
			if (turn == 1){
				this.labels[game.getLastLine()-1][game.getLastColumn()-1].setImage(this.crossImage);
			}else{
				this.labels[game.getLastLine()-1][game.getLastColumn()-1].setImage(this.circleImage);
			}
			int gameOver = game.gameOver();
			if (gameOver == 0) {
				this.messageBox.setMessage("Game over");
				this.messageBox.open();
			}
			else if (gameOver == 1) {
				GuessMyNumberMainWindow.displayAnimatedGif( null );
				this.messageBox.setMessage("Player 1 Won");
				this.messageBox.open();
				GuessMyNumberMainWindow.addPoint();
			}
			else if (gameOver == 2) {
				this.messageBox.setMessage("Player 2 Won");
				this.messageBox.open();
			}
			
			if ( humanTurn ){
				squareSelected(line, column);
			}
			
		}
		catch (PlayException pe) {
			this.messageBox.setMessage(pe.getMessage());
			this.messageBox.open();
		}
	}//squareSelected

	/**
	 * Reset the game and the display
	 */
	public void resetGame() {
		this.game.reset();
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++)
				this.labels[i][j].setImage(this.emptyImage);
		}
	}//resetGame

	/**
	 * Create a mouse listener for a square image
	 * @author R-One
	 */
	protected class SquareMouseListener extends MouseAdapter {
		
		// Selected line and column
		protected int line, column;
		
		/**
		 * Create the listener
		 * @param line Selected line
		 * @param column Selected column
		 */
		public SquareMouseListener(int line, int column) {
			this.line = line;
			this.column = column;
		}//Constructor
		
		/**
		 * Mouse down event processing
		 */
		public void mouseDown(MouseEvent e) {
			if (game != null)
				squareSelected(this.line,this.column);
		}//mouseDown
		
	}//SquareMouseListener

}//GameComposite
